package controle;
import modelo.Cartela_Bingo;
import modelo.Jogador;
import modelo.Pessoa;

import java.util.Scanner;

public class ControladoraBingo {

	public ControladoraBingo() {
		
	}
	
	public void resultadoBingo(int nSorteado, Jogador player1, Jogador player2) {
		int flag = 0;
		
		for(int i = 0; i < 10; i++) {
			if (player1.recuperaCartela().getNumeroCartela(i) == nSorteado) {
				player1.incrementaAcerto();
				player1.recuperaCartela().setNumeroCartela(i, 0);

				flag = 1;
			}
			
			if (player2.recuperaCartela().getNumeroCartela(i) == nSorteado) {
				player2.incrementaAcerto();
				player2.recuperaCartela().setNumeroCartela(i, 0);

				flag = 1;
			}
			
			if (flag == 1) {
				return;
			}
		}
	}
	
	public void reiniciarBingo(Jogador player) {
		player.recuperaCartela().reiniciaCartela();
	}
	
	public void recuperaVitorias(Jogador player) {
		player.getVitorias();
	}
	
	public void reiniciaAcerto(Jogador player) {
		player.setAcerto(0);
	}
}
