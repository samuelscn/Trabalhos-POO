package controle;
import modelo.Cartela_Bingo;
import modelo.Jogador;
import modelo.Pessoa;
import java.util.Random;

public class Roleta_Bingo {
int mesaBingo[];
	
	public Roleta_Bingo() {
		this.mesaBingo = new int[50];
		inicializaMesa();
	}

	private void inicializaMesa() {
		for (int i = 0; i < 50; i++) {
			this.mesaBingo[i] = 0;
		}
	}
	
	public int Rodar_Roleta() {
		Random gerador = new Random();
		boolean isExiste = false;
		int nSorteado;
		
		do {
			nSorteado = gerador.nextInt(50)+1;
			isExiste = analisaMesaBingo(nSorteado);
		}while(isExiste == true);
		
		setMesaBingo(nSorteado);
		return nSorteado;
	}
	
	public void Imprime_nSorteado(int nSorteado) {
		System.out.println("numero sorteado: "+nSorteado);
	}
	
	
	private boolean analisaMesaBingo(int nSorteado) {
		int flag = 0;
		
		for(int i = 0; i < 50; i++) {
			if (this.mesaBingo[i] == nSorteado) {
				flag = 1;
				return true;
			}
		}
		
		if(flag == 1) {
			return true;
		}else {
			return false;
		}
	}
	
	private void setMesaBingo(int nSorteado) {
		for(int i = 0; i < 50; i++) {
			if(this.mesaBingo[i] == 0) {
				this.mesaBingo[i] = nSorteado;
				return;
			}
		}	
	}
	
	public void imprimeMesaBingo() {
		for(int i = 0; i < 50; i++) {
			System.out.print(" "+this.mesaBingo[i]);
		}
	}


}
