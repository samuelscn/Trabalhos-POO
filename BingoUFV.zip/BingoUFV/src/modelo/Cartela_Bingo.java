package modelo;


import java.util.Random;

public class Cartela_Bingo {

	private int tamanhoCartela[];
	
	public Cartela_Bingo() {
		this.tamanhoCartela = new int[10];
		Gera_numeroCartela();
		System.out.println("Cartela criada com sucesso!");
	}
	
	private void Gera_numeroCartela() {
		Random gerador = new Random();
		
		for(int i = 0; i < 10; i++) {
			int nGerado = gerador.nextInt(50) + 1;
			
			if(this.tamanhoCartela[i] != nGerado) {
				this.tamanhoCartela[i] = nGerado;
			}
		}
	}
	
	public void Imprime_numeroCartela(Cartela_Bingo cartela) {
		for(int i = 0; i < 10; i++) {
			System.out.print(" "+cartela.tamanhoCartela[i]);
		}
	}
	
	public int getNumeroCartela(int i) {
		return this.tamanhoCartela[i];
	}
	
	public void setNumeroCartela(int i, int numero) {
		this.tamanhoCartela[i] = numero;
	}
	
	public void reiniciaCartela() {
		Gera_numeroCartela();
	}
	
}

