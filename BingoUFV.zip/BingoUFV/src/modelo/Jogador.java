package modelo;

public class Jogador extends Pessoa {

	private Cartela_Bingo cartela;
	private int contadorAcerto;
	private int nVitorias;
	
	public Jogador(String nome) {
		super(nome);
		this.cartela = new Cartela_Bingo();
		this.contadorAcerto = 0;
		this.nVitorias = 0;
	}
	
	public void imprime() {
		cartela.Imprime_numeroCartela(this.cartela);
	}

	public int getAcerto() {
		return this.contadorAcerto;
	}
	
	public void setAcerto(int zero) {
		this.contadorAcerto = zero;
	}
	
	public void incrementaAcerto() {
		this.contadorAcerto++;
	}
	
	public Cartela_Bingo recuperaCartela() {
		return this.cartela;
	}
	public int getVitorias() {
		return this.nVitorias;
	}
	
	public void setVitorias() {
		this.nVitorias++;
	}
}