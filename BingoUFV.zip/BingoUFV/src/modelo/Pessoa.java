package modelo;


public class Pessoa {

	private String nome;
	
	public Pessoa(String nome) {
		this.nome = nome;
		System.out.println("Jogador "+nome+" criado com sucesso!");
	}

	public String getNome() {
		return this.nome;
	}
	
}

