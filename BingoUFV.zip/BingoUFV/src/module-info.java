/**
 * 
 */
/**
 * @author vinicius
 *
 */
module BingoUFV {
}