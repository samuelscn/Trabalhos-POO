package visao;
import controle.ControladoraBingo;
import controle.Roleta_Bingo;
import modelo.Jogador;


import java.awt.EventQueue;

import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import javax.swing.JSlider;

public class teste {
	private JFrame frame;
	private int flagRodar = 0;
	private int flagPvsC = 0;
	private int flagJogador = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					teste window = new teste();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}
	public teste() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		Jogador player01 = new Jogador("Player 1");
		Jogador player02 = new Jogador("Maquina");
		Roleta_Bingo roleta = new Roleta_Bingo();
		ControladoraBingo cantaBingo = new ControladoraBingo();
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(10, 11, 414, 239);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblCartelaPlayer = new JLabel("Cartela player 1");
		lblCartelaPlayer.setBounds(10, 21, 196, 38);
		panel.add(lblCartelaPlayer);
		
		JLabel lblCartelaCom = new JLabel("Cartela COM01");
		lblCartelaCom.setBounds(10, 82, 196, 38);
		panel.add(lblCartelaCom);
		
		JLabel lblNumeroSorteado = new JLabel("Numero Sorteado: 0");
		lblNumeroSorteado.setBounds(70, 149, 136, 14);
		panel.add(lblNumeroSorteado);
		
		JLabel lblNumeroDeVitorias = new JLabel("Numero de Vitorias: 0");
		lblNumeroDeVitorias.setBounds(267, 59, 137, 14);
		panel.add(lblNumeroDeVitorias);
		
		
		JLabel lblNumeroDeVitorias_1 = new JLabel("Numero de Vitorias: 0");
		lblNumeroDeVitorias_1.setBounds(267, 109, 137, 14);
		panel.add(lblNumeroDeVitorias_1);
		
		JButton btnRodarARoleta = new JButton("Rodar a Roleta");
		btnRodarARoleta.setEnabled(false);
		btnRodarARoleta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(player01.getAcerto() < 5 && player02.getAcerto() < 5) {
					int nSorteado = roleta.Rodar_Roleta();
					cantaBingo.resultadoBingo(nSorteado, player01, player02);
					alteraValorSorteado(lblNumeroSorteado, nSorteado);
					alteraValorCartela(lblCartelaPlayer, player01);
					alteraValorCartela(lblCartelaCom, player02);
				}else if(player01.getAcerto() == 5) {
					System.out.println("BINGO! "+player01.getNome());
					player01.setVitorias();
					alteraValorVitoria(lblNumeroDeVitorias, player01);
					btnRodarARoleta.setEnabled(false);
					}else if(player02.getAcerto() == 5) {
						System.out.println("BINGO! "+player02.getNome());
						player02.setVitorias();
						alteraValorVitoria(lblNumeroDeVitorias_1, player02);
						btnRodarARoleta.setEnabled(false);
					}
			}
		});
		btnRodarARoleta.setBounds(56, 174, 130, 23);
		panel.add(btnRodarARoleta);
		
		
		JLabel lblPlayer = new JLabel("Player 1");
		lblPlayer.setBounds(267, 45, 118, 14);
		panel.add(lblPlayer);
		
		JLabel lblCom = new JLabel("COM 1");
		lblCom.setBounds(267, 94, 46, 14);
		panel.add(lblCom);
		
		JLabel lblPlayer_1 = new JLabel("Player 1");
		lblPlayer_1.setBounds(10, 11, 111, 14);
		panel.add(lblPlayer_1);
		
		JLabel lblCom_1 = new JLabel("COM");
		lblCom_1.setBounds(10, 70, 111, 14);
		panel.add(lblCom_1);
		
		JButton btnPlayerVsCom = new JButton("Iniciar Game");
		btnPlayerVsCom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(getFlagRodar() == 0) {
					if(getFlagJogador() == 0) {
						alteraValorJogador(lblPlayer);
						setFlagJogador();
					}
					setFlagRodar();
					setFlagPvsC();
					alteraValorCartela(lblCartelaPlayer, player01);
					alteraValorCartela(lblCartelaCom, player02);
					btnPlayerVsCom.setEnabled(false);
					btnRodarARoleta.setEnabled(true);
				}
			}
		});
		btnPlayerVsCom.setBounds(257, 152, 128, 23);
		panel.add(btnPlayerVsCom);
		
		JButton btnNewButton = new JButton("Reset Game");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				backFlagRodar();
				cantaBingo.reiniciarBingo(player01);
				cantaBingo.reiniciarBingo(player02);
				btnPlayerVsCom.setEnabled(true);
				cantaBingo.reiniciaAcerto(player01);
				cantaBingo.reiniciaAcerto(player02);
			}
		});
		btnNewButton.setBounds(257, 186, 128, 23);
		panel.add(btnNewButton);
		
		JLabel lblInformaesDoJogo = new JLabel("Informa\u00E7\u00F5es do Jogo");
		lblInformaesDoJogo.setBounds(257, 11, 138, 14);
		panel.add(lblInformaesDoJogo);
		
		
		JSeparator separator = new JSeparator();
		separator.setBounds(257, 83, 147, 2);
		panel.add(separator);
		
	}
	
	private void alteraValorCartela(JLabel cartela, Jogador player) {
		cartela.setText(""+player.recuperaCartela().getNumeroCartela(0)+" "+player.recuperaCartela().getNumeroCartela(1)+" "
				+player.recuperaCartela().getNumeroCartela(2)+" "+player.recuperaCartela().getNumeroCartela(3)+" "+player.recuperaCartela().getNumeroCartela(4)+
				" "+player.recuperaCartela().getNumeroCartela(5)+" "+player.recuperaCartela().getNumeroCartela(6)+" "
				+player.recuperaCartela().getNumeroCartela(7)+" "+player.recuperaCartela().getNumeroCartela(8)+" "+player.recuperaCartela().getNumeroCartela(9));
	}
	
	private void alteraValorJogador(JLabel cartela) {
		Scanner s = new Scanner(System.in);
		String nickname;
		System.out.println("Entre com seu nickname: ");
		nickname = s.next();
		cartela.setText(nickname);
	}
	
	private void setFlagRodar() {
		this.flagRodar = 1;
	}
	
	private void backFlagRodar() {
		this.flagRodar = 0;
	}
	
	private void setFlagPvsC() {
		this.flagPvsC = 1;
	}
	
	private int getFlagRodar() {
		return this.flagRodar;
	}
	
	private int getFlagPvsC() {
		return this.flagPvsC;
	}
	
	private int getFlagJogador() {
		return this.flagJogador;
	}
	
	private void setFlagJogador() {
		this.flagJogador = 1;
	}
	
	private void alteraValorSorteado(JLabel lblNumeroSorteado, int nSorteado) {
		lblNumeroSorteado.setText("Numero Sorteado: "+nSorteado);
	}
	
	private void alteraValorVitoria(JLabel nVitorias, Jogador player) {
		nVitorias.setText("Numero de Vitorias: "+player.getVitorias());
	}
	
	private void alteraNome(JLabel lblnome, Jogador player) {
		lblnome.setText(player.getNome());
	}
}
