import java.util.Scanner;
import java.util.ArrayList;

public class CtrlBiblioteca {
	private ArrayList<livro> livros = new ArrayList();
	private ArrayList<usuario> usuarios = new ArrayList();
	
	public CtrlBiblioteca(usuario user01, usuario user02, usuario user03, livro livro01, livro livro02, livro livro03) {
		this.usuarios.add(user01);
		this.usuarios.add(user02);
		this.usuarios.add(user03);
		this.livros.add(livro01);
		this.livros.add(livro02);
		this.livros.add(livro03);
	}
	
	public void Pesquisar_livro(String nome_Exemplar) {
		int n = livros.size();
		
		for(int i = 0; i < n; i++) {
			if(this.livros.get(i).getNome_Exemplar() == nome_Exemplar) {
				System.out.println("Livro existente na biblioteca!");
				System.out.println("Nome: "+this.livros.get(i).getNome_Exemplar());
				System.out.println("Autor: "+this.livros.get(i).getAutor());
				System.out.println("Editora: "+this.livros.get(i).getEditora());
				System.out.println("Ano de Publicacao: "+this.livros.get(i).getAnoPublicacao());
				System.out.println("Edicao: "+this.livros.get(i).getEdicao());
				System.out.println("Quantidade Existente na BBT: "+this.livros.get(i).getQtdExemplares());
			}else {
				System.out.println("Livro n�o existente na biblioteca!");
			}
		}
	}
	
	public void Solicita_emprestimo(int matricula, String nome_Exemplar) {
		if (Pesquisar_user_autenticado(matricula) == true) {
			if (Pesquisar_Exemplar(nome_Exemplar) == true) {
				if (Pesquisar_livros_emprestados(matricula) == true) {
					System.out.println("Livro emprestado com sucesso!");
					Diminui_Estoque_Livro(nome_Exemplar, matricula);
					Aumenta_Estoque_Usuario(matricula);
				}else {
					System.out.println("Usuario ja possui o numero maximo de livros a ser emprestado!");
				}
			}else {
				System.out.println("Estoque de livros atual e igual a zero!");
			}
		}else {
			System.out.println("Usuario inexistente ou nao autenticado!");
		}
	}
	
	private void Aumenta_Estoque_Usuario(int matricula) {
		int n = usuarios.size();
		
		for(int i = 0; i < n; i++) {
			if(this.usuarios.get(i).getMatricula() == matricula) {
				this.usuarios.get(i).aumentaLivrosEmMaos();
			}
		}
	}
	
	public void Consulta_Emprestimo(int matricula) {
		int n = livros.size();
		String titulo = new String();
		Scanner s = new Scanner(System.in);
		
		for(int i = 0; i < n; i++) {
			if(this.livros.get(i).getIdUser() == matricula) {
				System.out.println("Livro Emprestado: "+this.livros.get(i).getNome_Exemplar());
			}
		}
		System.out.println("Digite o nome do livro que deseja devolver: ");
		titulo = s.next();
		for(int i = 0; i < n; i++) {
			if(this.livros.get(i).getNome_Exemplar().equalsIgnoreCase(titulo)) {
				this.livros.get(i).setIdUser(0);
				this.livros.get(i).aumentaEstoqueAtual();
				this.usuarios.get(i).diminuiLivrosEmMaos();
				return;
			}
		}
	}
	
	private void Diminui_Estoque_Livro(String nome_Exemplar, int matricula) {
		int n = livros.size();
		
		for(int i = 0; i < n; i++) {
			if(this.livros.get(i).getNome_Exemplar() == nome_Exemplar) {
				this.livros.get(i).diminuiEstoqueAtual();
				this.livros.get(i).setIdUser(matricula);
			}
		}
	}
	
	private boolean Pesquisar_Exemplar(String nome_Exemplar) {
		int n = livros.size();
		
		for(int i = 0; i < n; i++) {
			if(this.livros.get(i).getNome_Exemplar() == nome_Exemplar) {
				if(this.livros.get(i).getEstoqueAtual() > 0) {
					return true;
				}
			}
		}
		return false;
	}
	
	private boolean Pesquisar_livros_emprestados(int matricula) {
		int n = usuarios.size();
		
		for(int i = 0; i < n; i++) {
			if(this.usuarios.get(i).getMatricula() == matricula) {
				if(this.usuarios.get(i).getLivrosEmMaos() >= 3) {
					return false;
				}else {
					return true;
				}
			}
		}
		return false;
	}
	
	private boolean Pesquisar_user_autenticado(int matricula) {
		int n = usuarios.size();
		
		for(int i = 0; i < n; i++) {
			if(this.usuarios.get(i).getMatricula() == matricula) {
				return this.usuarios.get(i).getAutenticado();
			}
		}
		return false;
	}
	
	public void Autentica_usuario(int matricula, int senha) {
		int n = usuarios.size();
		
		for(int i = 0; i < n; i++) {
			if(this.usuarios.get(i).getMatricula() == matricula && this.usuarios.get(i).getSenha() == senha) {
				if(this.usuarios.get(i).getAutenticado() == false) {
					System.out.println("Usuario "+this.usuarios.get(i).getNome()+" foi autenticado com sucesso!");
					this.usuarios.get(i).setAutenticado();
				}else {
					System.out.println("Usuario "+this.usuarios.get(i).getNome()+" ja e autenticado!");
					return;
				}
			}else {
				System.out.println("Usuario inexistente!");
			}
		}
	}
	
}
