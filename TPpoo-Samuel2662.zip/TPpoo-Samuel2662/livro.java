
public class livro {
	private int identificador;
	private String editora;
	private int edicao;
	private int Qtd_exemplares;
	private String autor;
	private String nome_Exemplar;
	private int ano_publicacao;
	private int estoque_atual;
	private int id_user;
	
	public livro(String autor, String nome_Exemplar, int ano_publicacao, String editora, int edicao, int Qtd_exemplares) {
		this.autor = autor;
		this.nome_Exemplar = nome_Exemplar;
		this.ano_publicacao = ano_publicacao;
		this.identificador = this.identificador + 1;
		this.editora = editora;
		this.edicao = edicao;
		this.Qtd_exemplares = Qtd_exemplares;
		this.estoque_atual = 1;
		this.id_user = 0;
	}
	
	public String getNome_Exemplar() {
		return this.nome_Exemplar;
	}
	
	public String getEditora() {
		return this.editora;
	}
	
	public String getAutor() {
		return this.autor;
	}
	
	public int getQtdExemplares() {
		return this.Qtd_exemplares;
	}
	
	public int getAnoPublicacao() {
		return this.ano_publicacao;
	}
	
	public int getEdicao() {
		return this.edicao;
	}
	
	public int getEstoqueAtual() {
		return this.estoque_atual;
	}
	
	public void diminuiEstoqueAtual() {
		this.estoque_atual--;
	}
	
	public void aumentaEstoqueAtual() {
		this.estoque_atual++;
	}
	
	public void setIdUser(int id_user) {
		this.id_user = id_user;
	}
	
	public int getIdUser() {
		return this.id_user;
	}
	
}
