import java.util.ArrayList;
import java.util.Scanner;

public class main {
	public void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int numero;
		String nome_Exemplar;
		int matricula;
		int senha;
		usuario user01 = new usuario(2662, "samuel", 1234, 1324, "palmeiras", 123456);
		usuario user02 = new usuario(2645, "simim", 345, 6665, "cansado", 654321);
		usuario user03 = new usuario(2647, "caiao", 1234, 1384, "mitologico", 567890);
		livro livro01 = new livro("francisco", "intermitencias", 1990, "saraiva", 9, 1);
		livro livro02 = new livro("saramago", "morte", 1995, "panini", 2, 1);
		livro livro03 = new livro("jose", "corvo", 1970, "alanpoe", 3, 1);
		CtrlBiblioteca sistema_biblioteca = new CtrlBiblioteca(user01, user02, user03, livro01, livro02, livro03);
		
		System.out.println("Bem-Vindo ao Sistema da Biblioteca!");
		System.out.println("Comandos disponiveis:");
		System.out.println("1 - Pesquisar por um livro a partir de seu titulo!");
		System.out.println("2 - Solicitar emprestimo de um livro!");
		System.out.println("3 - Consulte seus livros e solicite a devolucao de um deles!");
		System.out.println("4 - Seja um usuario autenticado no sistema da biblioteca!");
		
		do {
			System.out.println("Digite uma das numeracoes a cima para executar um comando: ");
			numero = s.nextInt();
		}while(numero > 4 || numero <= 0);
		
		switch(numero) {
			case 1:
				System.out.println("Digite o nome do livro a se pesquisa: ");
				nome_Exemplar = s.next();
				sistema_biblioteca.Pesquisar_livro(nome_Exemplar);
				break;
			case 2:
				System.out.println("Digite o numero da sua matricula: ");
				matricula = s.nextInt();
				System.out.println("Digite o nome do livro: ");
				nome_Exemplar = s.next();
				sistema_biblioteca.Solicita_emprestimo(matricula, nome_Exemplar);
				break;
			case 3:
				System.out.println("Digite o numero da sua matricula: ");
				matricula = s.nextInt();
				sistema_biblioteca.Consulta_Emprestimo(matricula);
				break;
			case 4:
				System.out.println("Digite o numero da sua matricula: ");
				matricula = s.nextInt();
				System.out.println("Digite sua senha: ");
				senha = s.nextInt();
				sistema_biblioteca.Autentica_usuario(matricula, senha);
				break;
		}
	}
}
