
public class usuario {
	private int matricula;
	private boolean isAutenticado;
	private String nome;
	private int id;
	private int cpf;
	private String endereco;
	private int senha;
	private int livros_em_maos;
	
	public usuario(int matricula, String nome, int id, int cpf, String endereco, int senha) {
		this.matricula = matricula;
		this.isAutenticado = false;
		this.livros_em_maos = 0;
		this.nome = nome;
		this.id = id;
		this.cpf = cpf;
		this.endereco = endereco;
		this.senha = senha;
	}
	
	public int getMatricula() {
		return this.matricula;
	}
	
	public boolean getAutenticado() {
		return this.isAutenticado;
	}
	
	public void setAutenticado() {
		this.isAutenticado = true;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public int getLivrosEmMaos() {
		return this.livros_em_maos;
	}
	
	public void setLivrosEmMaos(int qtd_livros) {
		this.livros_em_maos = qtd_livros;
	}
	
	public void aumentaLivrosEmMaos() {
		this.livros_em_maos++;
	}
	
	public void diminuiLivrosEmMaos() {
		this.livros_em_maos--;
	}
	
	public int getSenha() {
		return this.senha;
	}
	
}
