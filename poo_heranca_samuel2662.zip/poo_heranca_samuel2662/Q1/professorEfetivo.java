public class professorEfetivo extends professor{
    private int jornada_trabalho;
    private double salario;

    public professorEfetivo(String nome, int matricula, String data_nascimento, int jornada_trabalho, double salario) {
        super(nome, matricula, data_nascimento);
        this.jornada_trabalho = jornada_trabalho;
        this.salario = salario;
    }

    public int getJornada_trabalho() {
        return this.jornada_trabalho;
    }

    public double getSalario() {
        return this.salario;
    }

    public void setJornada_trabalho(int jornada_trabalho) {
        this.jornada_trabalho = jornada_trabalho;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public void valida_jornada() {
        
    }

}