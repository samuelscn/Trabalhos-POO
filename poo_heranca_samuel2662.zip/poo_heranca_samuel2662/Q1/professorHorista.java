public class professorHorista extends professor{
    private int horas_trabalhadas;
    private double salario_hora;

    public professorHorista(String nome, int matricula, String data_nascimento, int horas_trabalhadas, double salario_hora) {
        super(nome, matricula, data_nascimento);
        this.horas_trabalhadas = horas_trabalhadas;
        this.salario_hora = salario_hora;
    }

    public int getHoras_trabalhadas() {
        return this.horas_trabalhadas;
    }

    public double getSalario_hora() {
        return this.salario_hora;
    }

    public void setHoras_trabalhadas(int horas_trabalhadas) {
        this.horas_trabalhadas = horas_trabalhadas;
    }

    public void setSalario_hora(double salario_hora) {
        this.salario_hora = salario_hora;
    }

    public double calcula_salario() {
        return this.horas_trabalhadas*this.salario_hora;
    }
}