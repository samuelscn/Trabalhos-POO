import java.util.Scanner;

public class caminhao extends veiculo {
    private int capacidadeCarga;

    public caminhao(int numeroPlaca, int numeroEixo, double peso, int capacidadeCarga) {
        super(numeroPlaca, numeroEixo, peso);
        this.capacidadeCarga = validar_capacidade_carga(capacidadeCarga);
    }    

    public double getCapacidade_carga() {
        return this.capacidadeCarga;
    }

    public void setCapacidade_carga(int capacidadeCarga) {
        this.capacidadeCarga = capacidadeCarga
    }

    public int validar_capacidade_carga(int capacidadeCarga) {
        Scanner s = new Scanner(System.in);
        
        do {
            System.out.println("Capacidade maior que 45, entre com outra menor: ");
            capacidadeCarga = s.nextInt();
        } while(capacidadeCarga > 45)

        return capacidadeCarga;
    }

    public toString() {
        return "Caminhao de carga - capacidade "+getCapacidade_carga()+" toneladas"+toString(); 
    }
}