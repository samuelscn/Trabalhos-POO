public class onibus extends veiculo {
    private int numero_max_ocupantes;

    public onibus(int numeroPlaca, int numeroEixo, double peso, int numero_max_ocupantes) {
        super(numeroPlaca, numeroEixo, peso);
        this.numero_max_ocupantes = numero_max_ocupantes;
    }    

    public int getNumero_max_ocupantes() {
        return this.getNumero_max_ocupantes;
    }

    public void setNumero_max_ocupantes(int numero_max_ocupantes) {
        this.numero_max_ocupantes = numero_max_ocupantes;
    }

    public boolean valida_numero_ocupantes() {
        if ((getNumero_max_ocupantes() % 2) == 0) {
            return true;
        }
        return false;
    }

    public toString() {
        return "Onibus com capacidade para "+getNumero_max_ocupantes()+" ocupantes"+toString();
    }
}