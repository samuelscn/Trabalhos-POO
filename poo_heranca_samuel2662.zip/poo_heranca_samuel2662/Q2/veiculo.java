public class veiculo {
    private int numeroPlaca;
    private int numeroEixos;
    private double peso;

    public veiculo(int numeroPlaca, int numeroEixos, double peso) {
        this.numeroPlaca = numeroPlaca;
        this.numeroEixos = numeroEixos;
        this.peso = peso;
    }

    public int getNumero_placa() {
        return this.numeroPlaca;
    }

    public int getNumero_eixo() {
        return this.numeroEixos;
    }

    public double getPeso() {
        return this.peso;
    }

    public void setNumero_placa(int numeroPlaca) {
        this.numeroPlaca = numeroPlaca;
    }

    public void setNumero_eixo(int numeroEixos) {
        this.numeroEixos = numeroEixos;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public toString() {
        return "veiculo de placa: "+getNumero_placa();
    }
}