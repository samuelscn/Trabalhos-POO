/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetorefri;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Aluno
 */
public class Maquina_Refrigerante {
    private double Saldo;
    private ArrayList<Refrigerante> Qtd_Refrigerante = new ArrayList();
    private double Credito_Atual;

	public Maquina_Refrigerante(Refrigerante Coca, Refrigerante Pepsi, Refrigerante Fanta, Refrigerante Jesus, Refrigerante Tai) {
            this.Saldo = 10.0;
            this.Credito_Atual = 0.0;
            Qtd_Refrigerante.add(Coca);
            Qtd_Refrigerante.add(Pepsi);
            Qtd_Refrigerante.add(Fanta);
            Qtd_Refrigerante.add(Jesus);
            Qtd_Refrigerante.add(Tai);
	}

	public void Recebe_Credito(double moeda) {
		this.Credito_Atual = moeda;
	}

	public void Insere_Credito(double moeda) {
		this.Credito_Atual = this.Credito_Atual + moeda;
	}

	public double Exibe_Credito() {
		return this.Credito_Atual;
	}

	public String Escolha_Refrigerante(String Refri) {
		return Refri;
	}

	public void Altera_Estoque(String Refri) {
		int n = Qtd_Refrigerante.size();
		Scanner s = new Scanner(System.in);
		double moeda;

		for(int i = 0; i < n; i++) {
			if (this.Qtd_Refrigerante.get(i).getNome().equalsIgnoreCase(Refri)) {
				if (this.Credito_Atual >= this.Qtd_Refrigerante.get(i).getValor()) {
					System.out.println("Refrigerante retirado com sucesso!");
					this.Qtd_Refrigerante.get(i).setQtd(1);
                                        System.out.println("Numero de Refrigerante atual no estoque: "+Qtd_Refrigerante.get(i).getQtd());
					if (this.Credito_Atual > Qtd_Refrigerante.get(i).getValor()) {
                                                System.out.println("Seu troco e: "+this.Credito_Atual+ " - "+Qtd_Refrigerante.get(i).getValor());
						this.Credito_Atual = this.Credito_Atual - Qtd_Refrigerante.get(i).getValor();
                                                System.out.println("Troco: "+this.Credito_Atual);
					}
				return;
				}else {
					System.out.println("Saldo "+this.Exibe_Credito()+" insuficiente, insira mais moedas!");
					System.out.println("Insira a moeda: ");
					moeda = s.nextDouble();
					Insere_Credito(moeda);
					i = 0;
				}
			}
		}
	}
}
