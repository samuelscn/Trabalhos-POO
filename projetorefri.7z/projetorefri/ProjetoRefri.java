/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetorefri;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Aluno
 */
public class ProjetoRefri {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        double dinheiro;
        String refrigerante = new String();
        Refrigerante Coca = new Refrigerante("Coca", 3.0, 20);
        Refrigerante Pepsi = new Refrigerante("Pepsi", 2.50, 20);
        Refrigerante Fanta = new Refrigerante("Fanta", 1.0, 15);
        Refrigerante Jesus = new Refrigerante("Jesus", 0.50, 5);
        Refrigerante Tai = new Refrigerante("Tai", 2.0, 10);
        Maquina_Refrigerante Nova_Maquina = new Maquina_Refrigerante(Coca, Pepsi, Fanta, Jesus, Tai);
        
        System.out.println("Bem-Vindo a Maquina de Refrigerante!");
        System.out.println("Marca de Refrigerante e Valores disponiveis abaixo:");
        System.out.println("Marca: "+Coca.getNome()+" Valor: "+Coca.getValor()+" R$");
        System.out.println("Marca: "+Pepsi.getNome()+" Valor: "+Pepsi.getValor()+" R$");
        System.out.println("Marca: "+Fanta.getNome()+" Valor: "+Fanta.getValor()+" R$");
        System.out.println("Marca: "+Jesus.getNome()+" Valor: "+Jesus.getValor()+" R$");
        System.out.println("Marca: "+Tai.getNome()+" Valor: "+Tai.getValor()+" R$");
        System.out.println("Insira Credito na Maquina: ");
        dinheiro = s.nextDouble();
        Nova_Maquina.Recebe_Credito(dinheiro);
        System.out.println("Credito atual na Maquina: "+Nova_Maquina.Exibe_Credito());
        System.out.println("Escolha o Refrigerante a tomar: ");
        refrigerante = s.next();
        Nova_Maquina.Altera_Estoque(refrigerante);
    }
    
}
