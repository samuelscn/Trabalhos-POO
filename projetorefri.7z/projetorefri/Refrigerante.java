/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetorefri;

/**
 *
 * @author Aluno
 */
    public class Refrigerante {
        private String Nome;
        private double Valor;
        private int qtd;

    public Refrigerante(String Nome, double Valor, int qtd) {
            this.Nome = Nome;
            this.Valor = Valor;
            this.qtd = qtd;
    }

    public String getNome() {
            return this.Nome;
    }

    public double getValor() {
            return this.Valor;
    }

    public void setQtd(int qtd) {
            this.qtd = this.qtd - qtd ;
    }
    
    public int getQtd() {
        return this.qtd;
    }

    public void setValor(double Valor) {
            this.Valor = Valor;
    }
}
